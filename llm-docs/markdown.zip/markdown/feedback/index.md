# Feedback

We appreciate your feedback.

Give us your feedback on Slack: [keriworld.slack.com](https://keriworld.slack.com), #edu channel, channel ID: C03RB6ASVUM.