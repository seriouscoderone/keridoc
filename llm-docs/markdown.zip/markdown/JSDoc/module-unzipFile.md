# Module: unzipFile

Unzips a zip file to a specified destination directory

##### Parameters:

| Name | Type | Description |
| --- | --- | --- |

| `zipFilePath` | \* |  |
| `extractToDir` | \* |  |

Source:

-   [modules-js-node/unzipFile.mjs](https://weboftrust.github.io/keridoc/JSDoc/modules-js-node_unzipFile.md), [line 10](https://weboftrust.github.io/keridoc/JSDoc/modules-js-node_unzipFile.md#line10)