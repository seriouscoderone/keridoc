# Intro

[

## 📄️ KERIDoc

We aim to document everything related to KERI, ACDC and CESR and alike. To let autonomic identifiers florish.

](https://weboftrust.github.io/keridoc/docs/intro/intro.md)