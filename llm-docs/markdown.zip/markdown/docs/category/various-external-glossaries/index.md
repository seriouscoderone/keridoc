# Various external glossaries

[

## 📄️ External Digital Govt NZ Glossary

](https://weboftrust.github.io/keridoc/docs/glossaries-external/glossary-digital.govt.md)

[

## 📄️ External eSSIF-Lab Glossary

](https://weboftrust.github.io/keridoc/docs/glossaries-external/glossary-essiflab.md)

[

## 📄️ External Nist Glossary

](https://weboftrust.github.io/keridoc/docs/glossaries-external/glossary-nist.md)

[

## 📄️ External ToIP Glossary

](https://weboftrust.github.io/keridoc/docs/glossaries-external/glossary-toip.md)

[

## 📄️ External ToIP did:webs Glossary

w

](https://weboftrust.github.io/keridoc/docs/glossaries-external/glossary-toipdidweb.md)

[

## 📄️ External W3C DID Glossary

](https://weboftrust.github.io/keridoc/docs/glossaries-external/glossary-w3cdid.md)