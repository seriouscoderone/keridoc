# How we did

[

## 📄️ Intro

This is a source directory that explains how this site came to be and how it can be maintained.

](https://weboftrust.github.io/keridoc/docs/how-we-did/intro.md)

[

## 🗃️ general

2 items

](https://weboftrust.github.io/keridoc/docs/how-we-did/general/install-project-kerisse.md)

[

## 🗃️ glossary

4 items

](https://weboftrust.github.io/keridoc/docs/how-we-did/glossary/edit-metadata.md)

[

## 🗃️ keridoc

9 items

](https://weboftrust.github.io/keridoc/docs/how-we-did/keridoc/cheat-sheet-writing-page.md)

[

## 🗃️ kerific

2 items

](https://weboftrust.github.io/keridoc/docs/how-we-did/kerific/kerific-browser-extension.md)

[

## 🗃️ kerisse

4 items

](https://weboftrust.github.io/keridoc/docs/how-we-did/kerisse/create-search-index.md)