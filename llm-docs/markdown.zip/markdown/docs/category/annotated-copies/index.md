# Annotated Copies

[

## 📄️ WebOfTrust-ietf-acdc-main-draft-ssmith-acdc

Temporarily removed content, because the site won't generate.

](https://weboftrust.github.io/keridoc/docs/annotated-copies/WebOfTrust-ietf-acdc-main-draft-ssmith-acdc.md)

[

## 📄️ WebOfTrust-ietf-cesr-proof-main-draft-pfeairheller-cesr-proof

4493255410370, level 1

](https://weboftrust.github.io/keridoc/docs/annotated-copies/WebOfTrust-ietf-cesr-proof-main-draft-pfeairheller-cesr-proof.md)

[

## 📄️ WebOfTrust-ietf-ipex-main-draft-ssmith-ipex

248943216478, level 1

](https://weboftrust.github.io/keridoc/docs/annotated-copies/WebOfTrust-ietf-ipex-main-draft-ssmith-ipex.md)

[

## 📄️ WebOfTrust-keria-main-docs-protocol

signify-keria-request-authentication-protocol--skrap-, level 1

](https://weboftrust.github.io/keridoc/docs/annotated-copies/WebOfTrust-keria-main-docs-protocol.md)