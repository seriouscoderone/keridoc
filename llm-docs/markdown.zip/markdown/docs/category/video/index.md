# Video

[

## 📄️ 2024-03-24 KERI dev call

Why Zoom to KERISSE?

](https://weboftrust.github.io/keridoc/docs/video/2024-03-24-KERI-dev-call.md)

[

## 📄️ Let's KERI on together

The video

](https://weboftrust.github.io/keridoc/docs/video/lets-keri-on-together.md)