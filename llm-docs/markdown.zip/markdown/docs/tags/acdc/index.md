# One doc tagged with "ACDC"

[

## UNIVERSAL IDENTIFIER THEORY

](https://weboftrust.github.io/keridoc/docs/resources/mdfiles/IdentifierTheory-ssmith-uidt.md)

Samuel M. Smith Ph.D.\\