# Overrides

See: [https://github.com/WebOfTrustkeridoc/blob/main/search-index-typesense/overrides.sh#L6](https://github.com/WebOfTrustkeridoc/blob/main/search-index-typesense/overrides.sh#L6)