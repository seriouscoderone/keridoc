# Kerific Discord bot

See the [Kerific Discord Bot README.MD](https://github.com/kordwarshuis/kerific-discord-bot/blob/main/README.md)

Here you will find information on the Kerific Discord bot that is Hosted on Heroku. The bot can retrieve information concerning KERI.