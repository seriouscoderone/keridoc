# JavaScript documentation

[Client Side and NodeJS JavaScript documention using JSDoc (opens in new tab)](https://weboftrust.github.io/keridoc/JSDoc/index.md)