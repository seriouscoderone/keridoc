# File system

For who: maintainers and developers

WHy: traversing the file system and understand what you see

Result: faster more efficient and less error-prone work if we show and explain _how-we-did_ set it up.

See the [Docusaurus documentation](https://docusaurus.io) for a general explanation of the file system.

Here follows a brief description of the specific directories and files of KERISSE:

| @kordwarshuis |

![](https://weboftrust.github.io/keridoc/assets/images/file-system-1f73032f54e85c83f3eb836d232e7098.md)