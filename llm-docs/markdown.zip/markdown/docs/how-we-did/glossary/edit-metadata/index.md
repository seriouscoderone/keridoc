# Edit glossary metadata

The glossary metadata are currently hosted in Google Sheets.

The data are imported and rendered on [overview/overview-and-context](https://weboftrust.github.io/keridoc/docs/overview/overview-and-context.md)

Every cell has an edit and cancel button. Changes are currently not written to the google sheet, but are stored on an external server.

There is currently basic authentication: you need a Github token. If you try to save the edits in a cell this token will be requested.