# Animated visualisation of repo connections

See [visualisation](https://weboftrust.github.iokeridoc/visualisations/WebOfTrust/index.htm)