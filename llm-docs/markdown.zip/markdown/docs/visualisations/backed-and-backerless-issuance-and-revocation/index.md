# Backed and Backerless Issuance and Revocation

Flow charts created by Jason Colburne.

icpKELixnpVCbisra.dACDCrivcpiMGMTiiia.dixnpra.ivrtppa.dixna.da.ia.ia.ivcppbrvpra.ira.dia.da.ibackedissuance/revocation;

icpKELixnpVCissACDCrivcpiMGMTiiiaixnpria.da.iixnprevpia.da.ibackerlessissuance/revocationri;