# KERI & ACDC Architecture

Flow charts created by Kent Bull.

![KERI & ACDC Architecture - Ctlr-Node](https://weboftrust.github.io/keridoc/assets/images/KERI-&-ACDC-Architecture---Ctlr-Node-dbe8fbc881d44fbe8c297fc1d2437f2e.md) ![KERI & ACDC Architecture - Wit-Node](https://weboftrust.github.io/keridoc/assets/images/KERI-&-ACDC-Architecture---Wit-Node-e4d02448794d29f297a6188104f1f101.md)