# 2024-03-24 KERI dev call

We combined the delivery of a Zoom Meeting recording link and a KERISSE test to investigate how this would work in practise:

-   the editing with ffmpeg commandline tool
-   uploading and documenting on Youtube and finally
-   delivery of a big mp4 file hosted on Youtube.
```
00:19:37	Henk van Cann:	https://chat.openai.com/g/g-mTlHjxQCp-keri-wizzard

00:27:42	Henk van Cann:	Interested in what people suggest to feed the chatGPT engine for new developers to learn from and be able to question it

00:30:54	nkongsuwan:	https://github.com/WebOfTrust/keripy/discussions/726

00:32:03	Philip Feairheller:	https://github.com/WebOfTrust/cesr-test-vectors
```