# WOT Concepts

All the historical and actual concepts behind KERI and its off-springs