# Mindmap

[![hackmd-github-sync-badge](https://hackmd.io/AvVG2cZxQJCIe_VHQR8e8Q/badge)](https://hackmd.io/AvVG2cZxQJCIe_VHQR8e8Q)

This is a mindmap of the emcompassing concept of KERI and ACDC

1.  the things we've designed (whitepapers, technical designs)
2.  the things we've created (repos and code)
3.  the terminology we use.keridoc/

1.  to be better and quicker understood
2.  anchor our wording to our objectiveskeridoc/
3.  criteria how we distinguish importance to us

1.  the newbie digital identity expertkeridoc/
2.  the advanced SSI identity expert
3.  SSI expert

keridoc/

1.  static site generated on Github
2.  reuse resources all over the web
3.  can be searched and commented on keridoc/

1.  continuously from now
2.  automatic deployment at changes keridoc/

-   existance and persistance
-   access and transparency
-   privacy - consent to use
-   confidentiality - minimal disclosure

-   commitment and compliance to rules - signature
-   freedom of speech and movement - inception of AIDkeridoc/
-   self-sovereignty - portability, delegation and revocation
-   Protection – users’ rights, censorship-resistant

-   Self-sovereign security
-   portable identifiers
-   proofs verifiable to the root-of-trust
-   break down silos of control and surveillancekeridoc/

keridoc/

keridoc/

keridoc/

1.  authentic
2.  chained
3.  serialized data containers

1.  greater interoperability
2.  reduced ambiguity
3.  enhanced security
4.  better immutablykeridoc/

1.  Security first
2.  then confidentiality
3.  then privacy