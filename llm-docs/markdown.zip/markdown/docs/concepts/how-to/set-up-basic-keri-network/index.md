# Set up a basic KERI network

Lorem ipsum