# Verify a credential

Lorem ipsum