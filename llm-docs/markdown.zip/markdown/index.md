# KERIDoc

## Personal learning environment and consensus building tool

[

### ⚡ KERI Suite Documentation

doc.kerisse.org

](https://weboftrust.github.io/keridoc/)

[

### ⚡ KERI Suite Glossary

glossary.kerisse.org

](https://weboftrust.github.io/WOT-terms/)

[

### ⚡ KERI Suite Search Engine

search.kerisse.org

](https://weboftrust.github.io/kerisse/)